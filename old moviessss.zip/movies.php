<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Movie Website</title>
    <style>
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(120deg, #141414, #1f1f1f);
            color: #eee;
            margin: 0;
            padding: 0;
        }
        header {
            background: #000;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 6px rgba(0,0,0,0.6);
        }
        header h1 {
            color: #e50914;
            margin: 0;
        }
        nav a {
            color: #eee;
            text-decoration: none;
            margin: 0 15px;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #e50914;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #222;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.4);
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 8px;
            background: #333;
            color: #eee;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #e50914;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background: #b20710;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #444;
            text-align: center;
        }
        th {
            background: #e50914;
            color: white;
        }
        tr:nth-child(even) { background: #333; }
    </style>
</head>
<body>
<header>
    <h1>🎬 MyMovieSite</h1>
<?php if (isset($_SESSION['username'])): ?>
    <div style="background:#28a745;color:white;padding:10px;margin:15px;border-radius:8px;">
        ✅ Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>!
    </div>
<?php endif; ?>
    <nav>
        <a href="signup.php">Signup</a>
        <a href="feedback.php">Feedback</a>
        <a href="view_feedback.php">Admin</a>
    </nav>
</header>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Movies</title>
    <style>
        body {
            background-color: #000;
            color: #fff;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        /* 🔹 NAVBAR */
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #111;
            padding: 12px 30px;
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        .navbar .logo {
            font-size: 24px;
            font-weight: bold;
            color: #e50914;
        }
        .navbar ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
            gap: 20px;
        }
        .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
        }
        .navbar ul li a:hover {
            color: #e50914;
        }
        .search-box input {
            padding: 6px 12px;
            border-radius: 4px;
            border: none;
            outline: none;
            font-size: 14px;
        }

        /* 🔹 MAIN HEADING */
        h1 {
            text-align: center;
            padding: 20px 0 10px;
            font-size: 45px;
            font-weight: bold;
            color: #e50914;
        }
        h2 {
            margin: 40px 0 20px;
            text-align: center;
            font-size: 26px;
            font-weight: 500;
            color: #fff;
        }

        /* 🔹 MOVIE GRID */
        .movie-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 15px;
            padding: 0 20px 40px;
        }
        .movie-container a {
            display: block;
            text-decoration: none;
        }
        .movie-container img {
            width: 100%;
            height: 340px;
            object-fit: cover;
            border-radius: 8px;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .movie-container img:hover {
            transform: scale(1.07);
            box-shadow: 0 8px 20px rgba(229, 9, 20, 0.7);
        }

        /* 🔹 FOOTER */
        footer {
            margin-top: 20px;
            padding: 20px;
            background: #111;
            text-align: center;
            color: #aaa;
        }
    </style>
</head>
<body>
    <!-- 🔹 NAVBAR -->
    <div class="navbar">
        <div class="logo">🎬 MovieSite</div>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="#genres">Genres</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
        <div class="search-box">
            <input type="text" placeholder="🔍 Search movies...">
        </div>
    </div>

    <!-- 🔹 PAGE CONTENT -->
    <h1 id="genres">🎬 Welcome to MyMovieSite!</h1>

    <h2>🔥 Action Movies</h2>
    <div class="movie-container">
        <a href="movie.php?movie=fallguy"><img src="images/fallguy.jpg" alt="Fall Guy"></a>
        <a href="movie.php?movie=venom"><img src="images/venom.jpg" alt="Venom"></a>
        <a href="movie.php?movie=thedarkknight"><img src="images/thedarkknight.jpg" alt="The Dark Knight"></a>
        <a href="movie.php?movie=johnwick"><img src="images/johnwick.jpg" alt="John Wick"></a>
        <a href="movie.php?movie=remorse"><img src="images/remorse.jpg" alt="Without Remorse"></a>
    </div>

    <h2>👻 Horror Movies</h2>
    <div class="movie-container">
        <a href="movie.php?movie=hereditary"><img src="images/hereditary.jpg" alt="Hereditary"></a>
        <a href="movie.php?movie=consumed"><img src="images/consumed.jpg" alt="Consumed"></a>
        <a href="movie.php?movie=nightswim"><img src="images/nightswim.jpg" alt="Night Swim"></a>
        <a href="movie.php?movie=malignant"><img src="images/malignant.jpg" alt="Malignant"></a>
        <a href="movie.php?movie=conjuring"><img src="images/conjuring.jpg" alt="The Conjuring"></a>
    </div>

    <h2>❤️ Romantic Movies</h2>
    <div class="movie-container">
        <a href="movie.php?movie=kabirsingh"><img src="images/kabirsingh.jpg" alt="Kabir Singh"></a>
        <a href="movie.php?movie=kahonapyaarhai"><img src="images/kahonapyaarhai.jpg" alt="Kaho Na Pyaar Hai"></a>
        <a href="movie.php?movie=ddlj"><img src="images/ddlj.jpg" alt="Dilwale Dulhania Le Jayenge"></a>
        <a href="movie.php?movie=pyaarkiyatohdarnahaikya"><img src="images/pyaarkiyatohdarnahaikya.jpg" alt="Pyaar Kiya Toh Darna Kya"></a>
        <a href="movie.php?movie=diltohpagalhai"><img src="images/diltohpagalhai.jpg" alt="Dil To Pagal Hai"></a>
    </div>

    <h2>😂 Comedy Movies</h2>
    <div class="movie-container">
        <a href="movie.php?movie=yjhd"><img src="images/yjhd.jpg" alt="Yeh Jawaani Hai Deewani"></a>
        <a href="movie.php?movie=3idiots"><img src="images/3idiots.jpg" alt="3 Idiots"></a>
        <a href="movie.php?movie=stree"><img src="images/stree.jpg" alt="Stree"></a>
        <a href="movie.php?movie=golmaal"><img src="images/golmaal.jpg" alt="Golmaal"></a>
        <a href="movie.php?movie=mbbs"><img src="images/mbbs.jpg" alt="Munna Bhai MBBS"></a>
    </div>

    <footer>
        <p>&copy; 2025 Movie Website. All Rights Reserved.</p>
    </footer>
<script>
    const searchInput = document.querySelector('.search-box input');
    const movieCards = document.querySelectorAll('.movie-container a');

    searchInput.addEventListener('keyup', function() {
        const filter = searchInput.value.toLowerCase();
        movieCards.forEach(card => {
            const altText = card.querySelector('img').alt.toLowerCase();
            if (altText.includes(filter)) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }
        });
    });
</script>

</body>
</html>
