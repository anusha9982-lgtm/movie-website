<?php
session_start();

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "movie_db";
$port       = 3306;

$conn = new mysqli($servername, $username, $password, $dbname, $port);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = trim($_POST['username']);
    $pass = $_POST['password'];

    $sql = "SELECT user_id, username, password FROM users WHERE username=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user_id']  = $row['user_id'];
            $_SESSION['username'] = $row['username'];

            header("Location: movies.php?login=success");
            exit();
        } else {
            $_SESSION['error'] = "❌ Wrong password. Try again.";
            header("Location: login.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "❌ User not found. Please sign up first.";
        header("Location: signup.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
