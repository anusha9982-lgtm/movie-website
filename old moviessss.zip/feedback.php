<?php include 'header.php'; ?>
<div class="container" style="
    max-width: 500px; 
    margin: 60px auto; 
    text-align: center; 
    padding: 30px; 
    border-radius: 10px;
">
    <h2>Feedback</h2>
    <form action="feedback_process.php" method="POST" 
          style="display: flex; flex-direction: column; gap: 15px; width: 100%;">
        
        <input type="text" name="name" placeholder="Your Name" required 
               style="width: 100%; padding: 12px; box-sizing: border-box;">
        
        <input type="email" name="email" placeholder="Your Email" required 
               style="width: 100%; padding: 12px; box-sizing: border-box;">
        
        <textarea name="message" rows="5" placeholder="Your Feedback" required 
                  style="width: 100%; padding: 12px; box-sizing: border-box; resize: none;"></textarea>
        
        <button type="submit" 
                style="width: 100%; padding: 12px; cursor: pointer;">
            Submit Feedback
        </button>
    </form>
</div>
</body>
</html>