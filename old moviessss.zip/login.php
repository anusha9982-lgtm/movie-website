<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Login - MyMovieSite</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>MyMovieSite</h1>
    </header>
    <div class="container">
        <h2>Login</h2>

        <!-- Alert messages -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form action="login_process.php" method="POST">
            <input type="text" name="username" placeholder="Enter Username" required>
            <input type="password" name="password" placeholder="Enter Password" required>
            <button type="submit">Login</button>
        </form>
        <a href="signup.php">Don’t have an account? Sign up here</a>
    </div>
</body>
</html>
