<?php
session_start();
// Protect page: redirect if not logged in
if(!isset($_SESSION['username'])){
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Profile - My Movie Website</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>My Movie Website</h1>
    </header>
    <div class="container">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        <p><strong>Email:</strong> <?php echo isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : "Not set"; ?></p>
        <p><strong>Member since:</strong> <?php echo date("F j, Y"); ?></p>
        <a class="logout" href="logout.php">Logout</a>
    </div>
</body>
</html>
