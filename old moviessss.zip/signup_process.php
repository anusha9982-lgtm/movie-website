<?php
session_start();

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "movie_db";
$port       = 3306;

$conn = new mysqli($servername, $username, $password, $dbname, $port);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user = trim($_POST['username']);
    $pass = $_POST['password'];

    // check if username already exists
    $check_sql = "SELECT user_id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $user);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $_SESSION['error'] = "⚠️ Username already taken. Please choose another.";
        header("Location: signup.php");
        exit();
    }
    $check_stmt->close();

    // hash password
    $hashed_pass = password_hash($pass, PASSWORD_BCRYPT);

    // insert new user
    $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $user, $hashed_pass);

    if ($stmt->execute()) {
        $_SESSION['success'] = "✅ Signup successful! Please log in.";
        header("Location: login.php");
        exit();
    } else {
        $_SESSION['error'] = "Something went wrong. Try again.";
        header("Location: signup.php");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>
