<?php include 'header.php'; ?>

<?php
// ✅ Movie data for ALL posters from your index
$movies = [
    // ----- Action -----
    "fallguy" => [
        "title" => "The Fall Guy",
        "poster" => "images/fallguy.jpg",
        "description" => "Colt Seavers, a retired stuntman, is pulled back into the world of stunts when a movie star goes missing. Packed with daring action, comedy, and mystery.",
        "release" => "3 May 2024 (USA)",
        "director" => "David Leitch",
        "boxoffice" => "$181.1 million",
        "distributed" => "Universal Pictures",
        "basedon" => "The Fall Guy by Glen A. Larson",
        "cinematography" => "Jonathan Sela",
        "genre" => "Action, Comedy",
        "runtime" => "2h 6m",
        "rating" => "⭐ 7.5/10",
        "video" => "https://www.youtube.com/embed/EySdVK0NK1Y?si=roGu9pVnVSFfaVn5"
    ],
    "venom" => [
        "title" => "Venom",
        "poster" => "images/venom.jpg",
        "description" => "A journalist merges with an alien symbiote and gains superpowers. He must face powerful enemies while struggling with his dual identity.",
        "release" => "5 Oct 2018 (USA)",
        "director" => "Ruben Fleischer",
        "boxoffice" => "$856.1 million",
        "distributed" => "Sony Pictures",
        "basedon" => "Marvel Comics",
        "cinematography" => "Matthew Libatique",
        "genre" => "Action, Sci-Fi",
        "runtime" => "1h 52m",
        "rating" => "⭐ 6.7/10",
        "video" => "https://www.youtube.com/embed/__2bjWbetsA?si=g0NBIqmrRv5aSlM0"
    ],
    "thedarkknight" => [
        "title" => "The Dark Knight",
        "poster" => "images/thedarkknight.jpg",
        "description" => "Batman faces his greatest enemy, the Joker, who seeks to create chaos in Gotham City.",
        "release" => "18 July 2008 (USA)",
        "director" => "Christopher Nolan",
        "boxoffice" => "$1.006 billion",
        "distributed" => "Warner Bros. Pictures",
        "basedon" => "DC Comics character Batman",
        "cinematography" => "Wally Pfister",
        "genre" => "Action, Crime, Drama",
        "runtime" => "2h 32m",
        "rating" => "⭐ 9.0/10",
        "video" => "https://www.youtube.com/embed/EXeTwQWrcwY?si=sMiT0-9BzPz5cJqg"
    ],
    "johnwick" => [
        "title" => "John Wick",
        "poster" => "images/johnwick.jpg",
        "description" => "A retired hitman seeks vengeance after gangsters kill his dog, a final gift from his late wife.",
        "release" => "24 Oct 2014 (USA)",
        "director" => "Chad Stahelski",
        "boxoffice" => "$86 million",
        "distributed" => "Lionsgate",
        "basedon" => "Original story",
        "cinematography" => "Jonathan Sela",
        "genre" => "Action, Thriller",
        "runtime" => "1h 41m",
        "rating" => "⭐ 7.4/10",
        "video" => "https://www.youtube.com/embed/yNN2PoilSp4?si=GJcznneRcbEpAfoo"
    ],
    "remorse" => [
        "title" => "Without Remorse",
        "poster" => "images/remorse.jpg",
        "description" => "An elite Navy SEAL uncovers an international conspiracy while seeking justice for his wife's murder.",
        "release" => "30 Apr 2021 (USA)",
        "director" => "Stefano Sollima",
        "boxoffice" => "Amazon Prime Release",
        "distributed" => "Amazon Studios",
        "basedon" => "Novel by Tom Clancy",
        "cinematography" => "Philippe Rousselot",
        "genre" => "Action, Thriller",
        "runtime" => "1h 49m",
        "rating" => "⭐ 5.8/10",
        "video" => "https://www.youtube.com/embed/e-rw2cxFVLg?si=HqwkmZhlzZL6TKxc"
    ],

    // ----- Horror -----
    "hereditary" => [
        "title" => "Hereditary",
        "poster" => "images/hereditary.jpg",
        "description" => "A grieving family is haunted by disturbing events after the death of their secretive grandmother.",
        "release" => "21 June 2018 (USA)",
        "director" => "Ari Aster",
        "boxoffice" => "$82.8 million",
        "distributed" => "A24",
        "basedon" => "Original screenplay",
        "cinematography" => "Pawel Pogorzelski",
        "genre" => "Horror, Drama",
        "runtime" => "2h 7m",
        "rating" => "⭐ 7.3/10",
        "video" => "https://www.youtube.com/embed/V6wWKNij_1M?si=AHu-8u2019Tu7g7T"
    ],
    "consumed" => [
        "title" => "Consumed",
        "poster" => "images/consumed.jpg",
        "description" => "A psychological horror that explores paranoia and fear as a couple faces terrifying experiences.",
        "release" => "2023",
        "director" => "Unknown",
        "boxoffice" => "Limited Release",
        "distributed" => "Indie",
        "basedon" => "Original",
        "cinematography" => "Unknown",
        "genre" => "Horror, Thriller",
        "runtime" => "Approx. 1h 40m",
        "rating" => "⭐ 6.0/10",
        "video" => "https://www.youtube.com/embed/_8t2YK9splI?si=YvM6KYZ9RfsanCvw"
    ],
    "nightswim" => [
        "title" => "Night Swim",
        "poster" => "images/nightswim.jpg",
        "description" => "A family's backyard swimming pool becomes the site of supernatural horror.",
        "release" => "5 Jan 2024 (USA)",
        "director" => "Bryce McGuire",
        "boxoffice" => "$54.3 million",
        "distributed" => "Universal Pictures",
        "basedon" => "Short film",
        "cinematography" => "Charlie Sarroff",
        "genre" => "Horror",
        "runtime" => "1h 38m",
        "rating" => "⭐ 5.2/10",
        "video" => "https://www.youtube.com/embed/pcSNqteCEtE?si=9dw6ixUSC9KmVNIm"
    ],
    "malignant" => [
        "title" => "Malignant",
        "poster" => "images/malignant.jpg",
        "description" => "A woman is paralyzed by shocking visions of grisly murders, and her torment worsens when she discovers these waking dreams are terrifying realities.",
        "release" => "10 Sep 2021 (USA)",
        "director" => "James Wan",
        "boxoffice" => "$34.9 million",
        "distributed" => "Warner Bros.",
        "basedon" => "Original",
        "cinematography" => "Michael Burgess",
        "genre" => "Horror, Mystery",
        "runtime" => "1h 51m",
        "rating" => "⭐ 6.2/10",
        "video" => "https://www.youtube.com/embed/Gczt0fhawDs?si=j9CCN8Y9ZQLkePuN"
    ],
    "conjuring" => [
        "title" => "The Conjuring",
        "poster" => "images/conjuring.jpg",
        "description" => "Paranormal investigators Ed and Lorraine Warren help a family terrorized by a dark presence.",
        "release" => "19 July 2013 (USA)",
        "director" => "James Wan",
        "boxoffice" => "$319.5 million",
        "distributed" => "Warner Bros. Pictures",
        "basedon" => "True story",
        "cinematography" => "John R. Leonetti",
        "genre" => "Horror, Thriller",
        "runtime" => "1h 52m",
        "rating" => "⭐ 7.5/10",
        "video" => "https://www.youtube.com/embed/VFsmuRPClr4?si=MGTpMP2on9gw5ycD"
    ],

    // ----- Romantic -----
    "kabirsingh" => [
        "title" => "Kabir Singh",
        "poster" => "images/kabirsingh.jpg",
        "description" => "A brilliant but troubled surgeon descends into self-destruction after his girlfriend is forced to marry someone else.",
        "release" => "21 June 2019 (India)",
        "director" => "Sandeep Reddy Vanga",
        "boxoffice" => "₹379 crores",
        "distributed" => "T-Series",
        "basedon" => "Arjun Reddy",
        "cinematography" => "Sanjay Kumar",
        "genre" => "Romance, Drama",
        "runtime" => "2h 52m",
        "rating" => "⭐ 7.1/10",
        "video" => "https://www.youtube.com/embed/RiANSSgCuJk?si=2Mt9ctew-EeFCoGc"
    ],
    "kahonapyaarhai" => [
        "title" => "Kaho Naa... Pyaar Hai",
        "poster" => "images/kahonapyaarhai.jpg",
        "description" => "A young couple's romance is tragically cut short, but fate gives the girl another chance at love.",
        "release" => "14 Jan 2000 (India)",
        "director" => "Rakesh Roshan",
        "boxoffice" => "₹62 crores",
        "distributed" => "FilmKraft Productions",
        "basedon" => "Original",
        "cinematography" => "Kabir Lal",
        "genre" => "Romance, Musical",
        "runtime" => "2h 52m",
        "rating" => "⭐ 6.9/10",
        "video" => "https://www.youtube.com/embed/gsV-IjYLiYI?si=8oo0rE8ybQIdIP7p"
    ],
    "ddlj" => [
        "title" => "Dilwale Dulhania Le Jayenge",
        "poster" => "images/ddlj.jpg",
        "description" => "Raj and Simran meet in Europe, fall in love, and struggle against cultural traditions to be together.",
        "release" => "20 Oct 1995 (India)",
        "director" => "Aditya Chopra",
        "boxoffice" => "₹200 crores+",
        "distributed" => "Yash Raj Films",
        "basedon" => "Original",
        "cinematography" => "Manmohan Singh",
        "genre" => "Romance, Drama",
        "runtime" => "3h 9m",
        "rating" => "⭐ 8.0/10",
        "video" => "https://www.youtube.com/embed/oIZ4U21DRlM?si=bcQ8LKraj-kXGd35"
    ],
    "pyaarkiyatohdarnahaikya" => [
        "title" => "Pyaar Kiya Toh Darna Kya",
        "poster" => "images/pyaarkiyatohdarnahaikya.jpg",
        "description" => "A love story full of comedy, action, and drama between a fun-loving guy and a protective brother.",
        "release" => "27 Mar 1998 (India)",
        "director" => "Sohail Khan",
        "boxoffice" => "Hit",
        "distributed" => "GSK Entertainment",
        "basedon" => "Original",
        "cinematography" => "Santosh Thundiyil",
        "genre" => "Romantic Comedy",
        "runtime" => "2h 39m",
        "rating" => "⭐ 6.5/10",
        "video" => "https://www.youtube.com/embed/D5I0PPfMw3A?si=6mppaonKRRQd2WdX"
    ],
    "diltohpagalhai" => [
        "title" => "Dil To Pagal Hai",
        "poster" => "images/diltohpagalhai.jpg",
        "description" => "A love triangle forms within a dance troupe as dreams and destiny bring people together.",
        "release" => "30 Oct 1997 (India)",
        "director" => "Yash Chopra",
        "boxoffice" => "₹59 crores",
        "distributed" => "Yash Raj Films",
        "basedon" => "Original",
        "cinematography" => "Manmohan Singh",
        "genre" => "Romance, Musical",
        "runtime" => "2h 59m",
        "rating" => "⭐ 7.0/10",
        "video" => "https://www.youtube.com/embed/658ZWlnkPJQ?si=aXU5SSvIN2ep-h35"
    ],

    // ----- Comedy -----
    "yjhd" => [
        "title" => "Yeh Jawaani Hai Deewani",
        "poster" => "images/yjhd.jpg",
        "description" => "Four friends experience love, heartbreak, and friendship while navigating their dreams.",
        "release" => "31 May 2013 (India)",
        "director" => "Ayan Mukerji",
        "boxoffice" => "₹319 crores",
        "distributed" => "UTV Motion Pictures",
        "basedon" => "Original",
        "cinematography" => "V. Manikandan",
        "genre" => "Romantic Comedy",
        "runtime" => "2h 40m",
        "rating" => "⭐ 7.2/10",
        "video" => "https://www.youtube.com/embed/TVB920h0u4g?si=CCr2OKkxhketKj4_"
    ],
    "3idiots" => [
        "title" => "3 Idiots",
        "poster" => "images/3idiots.jpg",
        "description" => "Three friends navigate the pressures of college life, love, and friendship while challenging the system.",
        "release" => "25 Dec 2009 (India)",
        "director" => "Rajkumar Hirani",
        "boxoffice" => "₹460 crores",
        "distributed" => "Vinod Chopra Films",
        "basedon" => "Five Point Someone by Chetan Bhagat",
        "cinematography" => "C.K. Muraleedharan",
        "genre" => "Comedy, Drama",
        "runtime" => "2h 51m",
        "rating" => "⭐ 8.4/10",
        "video" => "https://www.youtube.com/embed/K0eDlFX9GMc?si=Oj4_aMgDWRqRnNW4"
    ],
    "stree" => [
        "title" => "Stree",
        "poster" => "images/stree.jpg",
        "description" => "A small town is haunted by a vengeful female spirit who preys on men during a festival.",
        "release" => "31 Aug 2018 (India)",
        "director" => "Amar Kaushik",
        "boxoffice" => "₹180 crores",
        "distributed" => "Maddock Films",
        "basedon" => "Folklore",
        "cinematography" => "Amalendu Chaudhary",
        "genre" => "Horror, Comedy",
        "runtime" => "2h 8m",
        "rating" => "⭐ 7.5/10",
        "video" => "https://www.youtube.com/embed/gzeaGcLLl_A?si=XPdTGcB8MD77yOf7"
    ],
    "golmaal" => [
        "title" => "Golmaal",
        "poster" => "images/golmaal.jpg",
        "description" => "Four college friends get involved in hilarious misadventures while trying to con a blind couple.",
        "release" => "14 Jul 2006 (India)",
        "director" => "Rohit Shetty",
        "boxoffice" => "Hit",
        "distributed" => "Shree Ashtavinayak Cine Vision",
        "basedon" => "Original",
        "cinematography" => "Aseem Bajaj",
        "genre" => "Comedy",
        "runtime" => "2h 30m",
        "rating" => "⭐ 7.4/10",
        "video" => "https://www.youtube.com/embed/ZmE6TN9bYQg?si=LxThu7m2j4hBJ3-u"
    ],
    "mbbs" => [
        "title" => "Munna Bhai M.B.B.S.",
        "poster" => "images/mbbs.jpg",
        "description" => "A gangster enrolls in medical school to fulfill his father’s dream, leading to hilarious and heartwarming moments.",
        "release" => "19 Dec 2003 (India)",
        "director" => "Rajkumar Hirani",
        "boxoffice" => "Blockbuster",
        "distributed" => "Vinod Chopra Films",
        "basedon" => "Original",
        "cinematography" => "Binod Pradhan",
        "genre" => "Comedy, Drama",
        "runtime" => "2h 36m",
        "rating" => "⭐ 8.1/10",
        "video" => "https://www.youtube.com/embed/6f-EaUWCua0?si=dDUfsNX6KZAM_80F"
    ]
];

// ✅ Get movie key from URL (?movie=fallguy)
$key = $_GET['movie'] ?? null;

if (!$key || !isset($movies[$key])) {
    echo "<h2 style='color:white; text-align:center; padding:50px;'>Movie not found</h2>";
    exit;
}

$movie = $movies[$key];
?>

<div class="movie-detail" style="background:url('<?php echo $movie['poster']; ?>') center/cover no-repeat;">
    <div class="overlay"></div>
    <div class="movie-info">
        <h1><?php echo $movie['title']; ?></h1>
        <p class="description"><?php echo $movie['description']; ?></p>

        <div class="details">
            <p><strong>Release date:</strong> <?php echo $movie['release']; ?></p>
            <p><strong>Director:</strong> <?php echo $movie['director']; ?></p>
            <p><strong>Box office:</strong> <?php echo $movie['boxoffice']; ?></p>
            <p><strong>Distributed by:</strong> <?php echo $movie['distributed']; ?></p>
            <p><strong>Based on:</strong> <?php echo $movie['basedon']; ?></p>
            <p><strong>Cinematography:</strong> <?php echo $movie['cinematography']; ?></p>
        </div>

        <div class="extra-info">
            <p><strong>Genre:</strong> <?php echo $movie['genre']; ?></p>
            <p><strong>Runtime:</strong> <?php echo $movie['runtime']; ?></p>
            <p><strong>Rating:</strong> <?php echo $movie['rating']; ?></p>
        </div>

        <button class="watch-btn" onclick="document.getElementById('movie-player').style.display='block'; this.style.display='none';">
            ▶ Watch Movie
        </button>

        <div id="movie-player" style="display:none; margin-top:30px;">
            <iframe width="100%" height="500" src="<?php echo $movie['video']; ?>" frameborder="0" allowfullscreen></iframe>
        </div>
    </div>
</div>

<style>
    .movie-detail {
        position: relative;
        padding: 60px;
        min-height: 100vh;
        display: flex;
        align-items: center;
        color: #fff;
    }
    .overlay {
        content: '';
        position: absolute;
        top:0; left:0; right:0; bottom:0;
        background: rgba(0,0,0,0.7);
    }
    .movie-info {
        position: relative;
        max-width: 700px;
        z-index: 1;
    }
    .movie-info h1 {
        font-size: 60px;
        color: #e50914;
        margin-bottom: 20px;
    }
    .description {
        font-size: 20px;
        line-height: 1.8;
        margin-bottom: 20px;
    }
    .details p, .extra-info p {
        margin: 6px 0;
        color: #ccc;
    }
    .watch-btn {
        margin-top: 20px;
        padding: 15px 35px;
        font-size: 20px;
        background: linear-gradient(90deg, #e50914, #b00610);
        border: none;
        border-radius: 8px;
        color: #fff;
        cursor: pointer;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .watch-btn:hover {
        transform: scale(1.1);
        box-shadow: 0 0 20px rgba(229,9,20,0.9);
    }
</style>

<footer style="text-align:center; padding:20px; background:#111; color:#aaa;">
    <p>&copy; 2025 Movie Website. All Rights Reserved.</p>
</footer>
</body>
</html>
