<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>My Movie Website</title>
    <style>
        body {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(120deg, #141414, #1f1f1f);
            color: #eee;
            margin: 0;
            padding: 0;
        }
        header {
            background: #000;
            padding: 15px 30px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 6px rgba(0,0,0,0.6);
        }
        header h1 {
            color: #e50914;
            margin: 0;
        }
        nav a {
            color: #eee;
            text-decoration: none;
            margin: 0 15px;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #e50914;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            background: #222;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.4);
        }
        input, select, textarea {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: none;
            border-radius: 8px;
            background: #333;
            color: #eee;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #e50914;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
        }
        button:hover {
            background: #b20710;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #fff;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #444;
            text-align: center;
        }
        th {
            background: #e50914;
            color: white;
        }
        tr:nth-child(even) { background: #333; }
    </style>
</head>
<body>
<header>
    <h1>🎬 MyMovieSite</h1>
    <nav>
        <a href="signup.php">Signup</a>
        <a href="feedback.php">Feedback</a>
        <a href="view_feedback.php">Admin</a>
    </nav>
</header>
