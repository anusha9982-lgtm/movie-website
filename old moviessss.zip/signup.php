<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Signup - MyMovieSite</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>MyMovieSite</h1>
    </header>
    <div class="container">
        <h2>Create an Account</h2>

        <!-- Alert messages -->
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert error"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>

        <form action="signup_process.php" method="POST">
            <input type="text" name="username" placeholder="Choose Username" required>
            <input type="email" name="email" placeholder="Enter Email" required>
            <input type="password" name="password" placeholder="Create Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Signup</button>
        </form>
        <a href="login.php">Already have an account? Login here</a>
    </div>
</body>
</html>
